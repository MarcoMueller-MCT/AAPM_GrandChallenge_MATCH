
load('GroundTruth.mat')

xAxisTimeLabel= [(1:size(HighComplexityGroundTruth(:,1)))/11];
figure('units','normalized','outerposition',[0 0.25 1 0.65]);
plot(xAxisTimeLabel,HighComplexityGroundTruth,'LineWidth',2); title('High Complexity','FontSize',16); ylim([-20,20]); xlim([0,150]); %legend('LR','SI','AP');
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Calibri','fontsize',24)
print(['HighComplexity'],'-dpng');
savefig(['HighComplexity.fig']);

xAxisTimeLabel= [(1:size(HighMotionGroundTruth(:,1)))/11];
figure('units','normalized','outerposition',[0 0.25 1 0.65]);
plot(xAxisTimeLabel,HighMotionGroundTruth,'LineWidth',2); title('High Motion','FontSize',16); ylim([-20,20]); xlim([0,150])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Calibri','fontsize',24)
print(['HighMotion'],'-dpng');
savefig(['HighMotion.fig']);

xAxisTimeLabel= [(1:size(MeanComplexityGroundTruth(:,1)))/11];
figure('units','normalized','outerposition',[0 0.25 1 0.65]);
plot(xAxisTimeLabel,MeanComplexityGroundTruth,'LineWidth',2); title('Mean Complexity','FontSize',16); ylim([-20,20]); xlim([0,150])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Calibri','fontsize',24)
print(['MeanComplexity'],'-dpng');
savefig(['MeanComplexity.fig']);

xAxisTimeLabel= [(1:size(MeanMotionGroundTruth(:,1)))/11];
figure('units','normalized','outerposition',[0 0.25 1 0.65]);
plot(xAxisTimeLabel,MeanMotionGroundTruth,'LineWidth',2); title('Mean Motion','FontSize',16); ylim([-20,20]); xlim([0,150])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Calibri','fontsize',24)
print(['MeanMotion'],'-dpng');
savefig(['MeanMotion.fig']);




std(HighComplexityGroundTruth)
nanstd(HighMotionGroundTruth)
nanstd(MeanComplexityGroundTruth)
std(MeanMotionGroundTruth)



